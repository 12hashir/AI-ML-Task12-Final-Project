import streamlit as st
import pandas as pd
import numpy as np
import joblib

# ── Page Configuration ──
st.set_page_config(
    page_title="Customer Churn Predictor",
    page_icon="📊",
    layout="centered"
)

# ── Load the saved model package ──
@st.cache_resource
def load_model():
    """Load the trained model, scaler, and encoders from disk."""
    package = joblib.load("churn_model.pkl")
    return package

package = load_model()
model          = package["model"]
scaler         = package["scaler"]
label_encoders = package["label_encoders"]
feature_names  = package["feature_names"]

# ── Header ──
st.title("📊 Customer Churn Prediction")
st.markdown("**CoreTech Solutions** — Predict whether a customer will churn based on their profile.")
st.divider()

# ── Sidebar — Model Info ──
with st.sidebar:
    st.header("ℹ️ Model Info")
    st.success(f"**Model:** {type(model).__name__}")
    st.info("**Task 12 — Final Project**\nCustomer Churn Prediction using Machine Learning")
    st.markdown("**Features used:**")
    for f in feature_names:
        st.markdown(f"- {f}")

# ── Input Form ──
st.subheader("Enter Customer Details")

col1, col2 = st.columns(2)

with col1:
    age             = st.slider("Age", 18, 70, 35)
    tenure_months   = st.slider("Tenure (Months)", 1, 72, 12)
    monthly_charges = st.number_input("Monthly Charges ($)", min_value=20.0, max_value=120.0, value=65.0, step=0.5)
    total_charges   = st.number_input("Total Charges ($)", min_value=20.0, max_value=10000.0, value=780.0, step=10.0)
    num_products    = st.selectbox("Number of Products", [1, 2, 3, 4, 5], index=1)

with col2:
    support_calls    = st.slider("Support Calls Made", 0, 10, 2)
    satisfaction     = st.selectbox("Satisfaction Score (1=Worst, 5=Best)", [1, 2, 3, 4, 5], index=3)
    contract_type    = st.selectbox("Contract Type", ["Month-to-Month", "One Year", "Two Year"])
    payment_method   = st.selectbox("Payment Method", ["Credit Card", "Bank Transfer", "Electronic Check", "Mailed Check"])
    internet_service = st.selectbox("Internet Service", ["Fiber Optic", "DSL", "No"])

st.divider()

# ── Prediction ──
if st.button("🔍 Predict Churn", type="primary", use_container_width=True):

    # Build raw input dict
    raw_input = {
        "Age": age,
        "Tenure_Months": tenure_months,
        "Monthly_Charges": monthly_charges,
        "Total_Charges": total_charges,
        "Num_Products": num_products,
        "Support_Calls": support_calls,
        "Satisfaction_Score": satisfaction,
        "Contract_Type": contract_type,
        "Payment_Method": payment_method,
        "Internet_Service": internet_service,
    }

    # Encode categorical columns using saved label encoders
    encoded_input = raw_input.copy()
    for col in ["Contract_Type", "Payment_Method", "Internet_Service"]:
        encoded_input[col] = label_encoders[col].transform([encoded_input[col]])[0]

    # Create DataFrame in correct feature order
    input_df = pd.DataFrame([encoded_input])[feature_names]

    # Scale features
    input_scaled = scaler.transform(input_df)

    # Predict
    prediction   = model.predict(input_scaled)[0]
    probability  = model.predict_proba(input_scaled)[0]

    churn_prob    = probability[1] * 100
    no_churn_prob = probability[0] * 100

    st.subheader("Prediction Result")

    if prediction == 1:
        st.error(f"⚠️ **This customer is likely to CHURN**")
        st.markdown(f"Churn Probability: **{churn_prob:.1f}%**")
    else:
        st.success(f"✅ **This customer is NOT likely to churn**")
        st.markdown(f"Retention Probability: **{no_churn_prob:.1f}%**")

    # Probability bar chart
    st.subheader("Prediction Confidence")
    prob_df = pd.DataFrame({
        "Outcome": ["Will NOT Churn", "Will Churn"],
        "Probability (%)": [round(no_churn_prob, 2), round(churn_prob, 2)]
    })
    st.bar_chart(prob_df.set_index("Outcome"))

    # Show encoded input for transparency
    with st.expander("View Processed Input Data"):
        st.dataframe(input_df)

# ── Footer ──
st.divider()
st.caption("Task 12 — Final Project | CoreTech Customer Churn Prediction | Built with Streamlit & Scikit-learn")
